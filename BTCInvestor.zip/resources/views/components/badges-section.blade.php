<div class="my-5">

    <section class="container-fluid p-5" style="background: {{ env('APP_WHITE_COLOR') }} !important;">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <img src="{{ asset('img/paypal2.png') }}" class="responsive-img badge-img" alt="verified">
                </div>
                <div class="col-md-3">
                    <img src="{{ asset('img/mastercard.jpeg') }}" class="responsive-img badge-img" alt="verified">
                </div>
                <div class="col-md-3">
                    <img src="{{ asset('img/security.png') }}" class="responsive-img badge-img" alt="verified">
                </div>
                <div class="col-md-3">
                    <img src="{{ asset('img/visa2.jpeg') }}" class="responsive-img badge-img" alt="verified">
                </div>
            </div>
        </div>
    </section>

</div>
