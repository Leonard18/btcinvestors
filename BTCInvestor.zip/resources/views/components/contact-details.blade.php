<div class="my-5">

    <div class="container-fluid p-5 rounded" style="background: {{ env('APP_WHITE_COLOR') }} !important;">
        <div class="section-header">
            <h3 class="pb-4 underline" style="color: {{ env('APP_PRIMARY_COLOR') }} !important;">Contact Details</h3>
        </div>
       <div class="row">

        <div class="col s12 l4">
            <h5><i class="fa fa-phone-square"></i> PHONE</h5>
            <h6>+2349058848685</h6>
        </div>
        <div class="col s12 l4">
            <h5><i class="fa fa-envelope"></i></i> EMAIL</h5>
            <h6>support@btcinvestor.com</h6>
        </div>
        <div class="col s12 l4">
            <h5><i class="fa fa-map-marker"></i> LOCATION</h5>
            <h6>#23 New Road,m NY, USA</h6>
        </div>
            
       </div>
    </div>

</div>

