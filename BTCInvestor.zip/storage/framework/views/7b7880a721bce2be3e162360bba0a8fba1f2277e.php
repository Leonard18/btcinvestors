<?php $__env->startSection('headerContent'); ?>
    <meta name="description" content="<?php echo e(config('app.name')); ?> - Investment Plans">
    <title><?php echo e(config('app.name')); ?> - Investment Plans</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-name'); ?>
    Investment Plans
    <?php $__env->startSection('small-page-name', 'investment-plans'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="my-5">

    <div class="container-fluid p-5" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important;">
        <div class="section-header pb-4 center">
            <div class="row justify-content-between">
                <div class="col-md-10">
                    <h1 class="section-header-text" style="color: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">Investment Plans</h1>
                </div>
                
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
			<div class="col-md-2 pt-4">


				 <!-- Modal Trigger -->
			
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
				<a class="waves-effect waves-light btn modal-trigger green darken-2 white-text" href="#modal-plan">Add Plan</a>
			<?php endif; ?>
                    

                    <!-- Modal Structure -->
                    <div id="modal-plan" class="modal modal-fixed-footer py-3">
                      <div class="modal-content">
                        <h4>Add New Investment Plan</h4>
                        <p>Add an investment plan to allow users a new investment opportunity.</p>
                        <hr>
                        <div class="row">
                            <div class="col s12 l12">
                                <form action="<?php echo e(route('plan.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="input-field col s12 l4">
                                        <input type="text" name="name" id="name" class="validate" placeholder="Name of investment plan">
                                        <label for="name" data-error="wrong" data-success="right">Plan Name<span class="red-text"> *</span></label>
                                    </div>

                                    <div class="input-field col s12 l4">
                                        <input type="number" name="percentage" id="percentage" class="validate" placeholder="Percentage of plan">
                                        <label for="percentage" data-error="wrong" data-success="right">Plan Percentage<span class="red-text"> *</span></label>
                                    </div>

                                    <div class="input-field col s12 l4">
                                        <select name="interval" id="interval">
                                            <option selected disabled>Select plan in</option>
                                            <option value="1">Weekly</option>
                                            <option value="2">Bi-Weekly</option>
                                            <option value="3">Monthly </option>
                                            <option value="4">Two Months</option>
                                            <option value="5">Three Months</option>
                                            <option value="6">Six Months</option>
                                            <option value="7">Ten Months</option>
					    <option value="8">Twelve Months</option>
                                        </select>
                                        <label for="interval" data-error="wrong" data-success="right">Plan Interval<span class="red-text"> *</span></label>
                                    </div>

                                     <div class="input-field col s12 l4">
                                        <select name="duration" id="duration">
                                            <option value="" selected disabled>Select plan duration</option>
                                            <option value="Weekly">Weekly</option>
                                            <option value="Bi-Weekly">Bi-Weekly</option>
                                            <option value="Monthly">Monthly</option>
                                            <option value="Two Months">Two Months</option>
                                            <option value="Three Months">Three Months</option>
                                            <option value="Six Months">Six Months</option>
                                            <option value="Ten Months">Ten Months</option>
                                            <option value="Twelve Months">Twelve Months</option>
                                            <option value="Twelve Months">Fifteen Months</option>
                                            <option value="Twelve Months">Eighteen Months</option>
                                            <option value="Twelve Months">Twenty-four Months</option>
                                            <option value="Twelve Months">Thirty-six Months</option>
                                        </select>
                                        <label for="duration" data-error="wrong" data-success="right">Plan Duration<span class="red-text"> *</span></label>
                                    </div>

                                     <div class="input-field col s12 l4">
                                        <input type="color" name="background_color" id="background_color" class="validate p-1" style="width: 100% !important; border: 2px solid black !important;">
                                        <label for="background_color" data-error="wrong" data-success="right">Plan Background Color<span class="red-text"> *</span></label>
                                    </div>

                                    <div class="input-field col s12 l4">
                                        <input type="color" name="text_color" id="text_color" class="validate p-1" style="width: 100% !important; border: 2px solid black !important;">
                                        <label for="text_color" data-error="wrong" data-success="right">Plan Text Color<span class="red-text"> *</span></label>
                                    </div>

                                    <div class="input-field col s12 l12">
                                        <textarea id="description" name="description" class="materialize-textarea" placeholder="Describe plan" cols="30" rows="10"></textarea>
                                        <label for="description" data-error="wrong" data-success="right">Plan Description<span class="red-text"> *</span></label>
                                    </div>
                            </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                         <button type="submit" class="btn btn-large purple darken-2 white-text">Add New Plan</button>
                        <a href="#!" class=" modal-action modal-close waves-effect waves-green btn-flat">Close</a>
                      </div>
                    </form>
                    </div>

               </div>				
                   
        		</div>
			<?php endif; ?>
		
        <div class="row">

            <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-6 col-lg-6">
                <div class="card" style="background: <?php echo e($plan->background_color); ?>">
                    <div class="card-header center" style="width: 100% !important;">
                        <h1 class="card-title font-weight-bold" style="color: <?php echo e($plan->text_color); ?> !important;"><?php echo e($plan->name); ?></h1>
                    </div>
                    <div class="card-content center" style="color: <?php echo e($plan->text_color); ?>">
                        <h1 class="price-header"><?php echo e($plan->percentage); ?>%</h1>
                        <p>paid once every <?php echo e($plan->interval_name); ?></p>
                    </div>
                    <div class="card-action center">
                        <!-- Button trigger modal -->
                        <a class="btn-link" data-toggle="modal" data-target="#modelId-<?php echo e($plan->id); ?>" style="cursor: pointer !important; color: <?php echo e($plan->text_color); ?>;">
                          View details
                        </a>

                        <button class="btn btn-large my-3 btn-block font-weight-bolder" style="background: <?php echo e($plan->text_color); ?>;"><a href="<?php echo e(route('make-deposit')); ?>" style="color: <?php echo e($plan->background_color); ?>">INVEST NOW</a></button>

                        <!-- Modal -->
                        <div class="modal fade" id="modelId-<?php echo e($plan->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                        <div class="modal-header">
                                                <h5 class="modal-title"><?php echo e($plan->name); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                            </div>
                                    <div class="modal-body">
                                        <div class="container-fluid">
                                            Add rows here
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-primary">Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <script>
                            $('#exampleModal').on('show.bs.modal', event => {
                                var button = $(event.relatedTarget);
                                var modal = $(this);
                                // Use above variables to manipulate the DOM

                            });
                        </script>
                    </div>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>There are no plans on the platform. Create one</p>
            <?php endif; ?>


            </div>
        </div>
    </div>


    
    <div class="my-5">

        <div class="container-fluid p-5 rounded" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important;">
            <h3 class="pb-4 underline" style="color: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">Your Transaction History</h3>

           <table class="table responsive-table table-striped table-hover">
               <thead class="orange darken-2 white-text">
                   <tr>
                       <th data-field="id">#</th>
                       <th data-field="name">Type</th>
                       <th data-field="price">Description</th>
                       <th data-field="price">Date</th>
                       <th data-field="price">Extras</th>
                       <th data-field="price">Status</th>
                   </tr>
               </thead>
               <tbody>
                   <?php $__empty_1 = true; $__currentLoopData = $userTrans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userTran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                       <tr>
                          <td><?php echo e($userTran->id); ?></td>
                          <td><?php echo e($userTran->type); ?></td>
                          <td><?php echo e($userTran->description); ?></td>
                          <td><?php echo e($userTran->created_at); ?></td>
                          <td><?php echo e($userTran->extras); ?></td>
                          <td><?php echo e($userTran->status ? 'Success' : 'Declined'); ?></td>
                       </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                       <tr>
                           <td colspan="6">There are no transactions yet. Create one.</td>
                       </tr>
                   <?php endif; ?>
               </tbody>
           </table>

          </div>

    </div>
    




<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerContent'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Leonard\Development\PHP\Laravel\NewProjects\BTCInvestor\resources\views/user/investment-plans.blade.php ENDPATH**/ ?>