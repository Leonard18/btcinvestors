<div class="my-3">

    <div class="rounded-md p-5 login-form-section container" style="background: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">
      <form action="<?php echo e(route('register')); ?>" method="POST" class="form-login-register">
            <?php echo csrf_field(); ?>
          <div class="row">
            <div class="form-group col-md-6">
                <input type="text" name="first-name" id="first-name" class="form-control rounded pl-3" placeholder="First name *" value="<?php echo e(old('first-name')); ?>" aria-describedby="first-name" style="border: 1px solid <?php echo e(env('APP_WHITE_COLOR')); ?> !important;  width: 95% !important;">
                <?php $__errorArgs = ['first-name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="red-text"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6">
                <input type="text" name="middle-name" id="middle-name" class="form-control rounded pl-3" placeholder="Middle name" value="<?php echo e(old('middle-name')); ?>" aria-describedby="middle-name" style="border: 1px solid <?php echo e(env('APP_WHITE_COLOR')); ?> !important;  width: 95% !important;">
                <?php $__errorArgs = ['middle-name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="red-text"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6">
                <input type="text" name="last-name" id="last-name" class="form-control rounded pl-3" placeholder="Last name" value="<?php echo e(old('last-name')); ?>" aria-describedby="last-name" style="border: 1px solid <?php echo e(env('APP_WHITE_COLOR')); ?> !important;  width: 95% !important;">
                <?php $__errorArgs = ['last-name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="red-text"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6">
                <input type="text" name="username" id="username" class="form-control rounded pl-3" placeholder="Choose username" value="<?php echo e(old('username')); ?>" aria-describedby="username" style="border: 1px solid <?php echo e(env('APP_WHITE_COLOR')); ?> !important;  width: 95% !important;">
                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="red-text"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6">
                <input type="text" name="email" id="email" class="form-control rounded pl-3" placeholder="Email address" value="<?php echo e(old('email')); ?>" aria-describedby="email" style="border: 1px solid <?php echo e(env('APP_WHITE_COLOR')); ?> !important;  width: 95% !important;">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="red-text"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6">
                <input type="text" name="phone" id="phone" class="form-control rounded pl-3" placeholder="Phone number" value="<?php echo e(old('phone')); ?>" aria-describedby="phone" style="border: 1px solid <?php echo e(env('APP_WHITE_COLOR')); ?> !important;  width: 95% !important;">
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="red-text"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6">
                <input type="password" name="password" id="password" class="form-control rounded pl-3" placeholder="Enter a password" aria-describedby="password" style="border: 1px solid <?php echo e(env('APP_WHITE_COLOR')); ?> !important;  width: 95% !important;">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="red-text"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6">
                <input type="password" name="password_confirmation" id="password_confirmation" class="form-control rounded pl-3" placeholder="Confirm password" aria-describedby="password_confirmation" style="border: 1px solid <?php echo e(env('APP_WHITE_COLOR')); ?> !important;  width: 95% !important;">
                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="red-text"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <button type="submit" class="btn btn-block font-weight-bolder btn-large bg-white hover:bg-blue-100" role="button" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important; color: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important; width: 100% !important;">CREATE ACCOUNT</button>
      </form>

    </div>

</div>
<?php /**PATH C:\Users\user\Desktop\Leonard\Development\PHP\Laravel\NewProjects\BTCInvestor\resources\views/components/register-form.blade.php ENDPATH**/ ?>