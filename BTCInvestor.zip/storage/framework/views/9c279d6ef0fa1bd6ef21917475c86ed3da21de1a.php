<?php $__env->startSection('headerContent'); ?>
   <meta name="description" content="Register - <?php echo e(config('app.name')); ?>">
   <title><?php echo e(config('app.name')); ?>- Register</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-name'); ?>
    Register
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <section style="background: <?php echo e(env('APP_WHITE_COLOR')); ?>" class="p-5 container">
       <div class="row">
           <div class="col-md-4 my-3 p-4">
               <h3 class="pb-2">Create Account</h3>
               <p>Create account by filling all form fields. <span class="red-text font-bold">ALL FIELDS ARE REQUIRED.</span></p>
               <p>Make sure you're on the right URL <button class="btn rounded" disabled><strong class="black-text"><?php echo e(route('register')); ?> </strong></button> before proceeding with the registration process.</p>
           </div>
           <div class="col-md-7 offset-md-1">
               <?php if (isset($component)) { $__componentOriginal1fd73546c50a37fa4f927b03db10561076336eac = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\RegisterForm::class, []); ?>
<?php $component->withName('register-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal1fd73546c50a37fa4f927b03db10561076336eac)): ?>
<?php $component = $__componentOriginal1fd73546c50a37fa4f927b03db10561076336eac; ?>
<?php unset($__componentOriginal1fd73546c50a37fa4f927b03db10561076336eac); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
           </div>
       </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerContent'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Leonard\Development\PHP\Laravel\NewProjects\BTCInvestor\resources\views/auth/register.blade.php ENDPATH**/ ?>