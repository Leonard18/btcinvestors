<?php $__env->startSection('headerContent'); ?>
    <meta name="description" content="<?php echo e(config('app.name')); ?> - Make Deposit">
    <title><?php echo e(config('app.name')); ?> - Make Deposit</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-name'); ?>
    Make Deposit
    <?php $__env->startSection('small-page-name', 'make-deposit'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="my-5">

        <div class="container-fluid p-5 rounded" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important;">

           
           <h3 class="pb-4 underline grey-text">Make Deposit</h3>
                
               <?php if(Session::has('success')): ?>
                <div class="col s12 l12 green p-4">
                    <ul class="collection with-header s12 l12">

                        <li class="collection-header">
                        <h1>Deposit Info</h1>
                        </li>
                        <li class="collection-item"><div>Plan name <span class="secondary-content" style="font-weight: bolder !important;"><?php echo e(session('plan_name')); ?></span></div></li>

                        <li class="collection-item"><div>Investment amount <span class="secondary-content" style="font-weight: bolder !important;"><?php echo e(session('investment_amount')); ?></span></div></li>

                        <li class="collection-item"><div>Expected return <span class="secondary-content" style="font-weight: bolder !important;"><?php echo e(session('expected_amount')); ?></span></div></li>
                        <li class="collection-item"><div>Interval <span class="secondary-content" style="font-weight: bolder !important;"><?php echo e(session('plan_interval')); ?></span></div></li>
                    </ul>
                </div>
               <?php endif; ?>
               
           <div class="row">

               <div class="col s8 m8 l8 mt-40">
                   <form action="<?php echo e(route('new-deposit')); ?>" method="POST">
                       <?php echo csrf_field(); ?>
                     <div class="input-field col s12 l6">
                       <select name="investment_plan" id="investment_plan">
                           <option value="" disabled selected>Select investment plan</option>
                           <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($plan->id); ?>"><?php echo e($plan->name); ?> - commission paid <?php echo e($plan->interval); ?> </option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>
                       <label for="investment_plan">Select investment plan</label>
                     </div>
                     <div class="input-field col s12 l6">
                       <input type="number" name="investment_amount" id="investment_amount" class="validate">
                       <label for="investment_amount">Amount to invest</label>
                     </div>
                     <button type="submit" class="btn btn-large btn-block white-text green">INVEST NOW</button>
                   </form>
               </div>
           </div>


        </div>


    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerContent'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Leonard\Development\PHP\Laravel\NewProjects\BTCInvestor\resources\views/user/make-deposit.blade.php ENDPATH**/ ?>