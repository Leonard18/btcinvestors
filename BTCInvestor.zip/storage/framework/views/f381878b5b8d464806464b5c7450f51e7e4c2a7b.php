<div class="my-3">

    <div class="rounded-md p-4 login-form-section container" style="background: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">
       <div class="row justify-content-center center">
           <div class="col-md-10">
            <form action="<?php echo e(route('login')); ?>" method="POST" class="form-login-register pt-3">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input type="text" name="email" id="email" class="form-control rounded pl-3 border-white <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email/Username" value="<?php echo e(old('email')); ?>" style="width: 95% !important;">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="red-text"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                  <input type="password" name="password" id="password" class="form-control rounded pl-3 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" style="border: 1px solid <?php echo e(env('APP_WHITE_COLOR')); ?> !important;  width: 95% !important;">
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="red-text"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <button type="submit" class="btn btn-block font-weight-bolder btn-large bg-white hover:bg-blue-100" role="button" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important; color: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important; width: 100% !important;">Log In</button>
            </form>

            
            <div class="row mt-20">
                <div class="col m6 s6">
                    <a href="<?php echo e(route('password.request')); ?>" class="grey-text">Forgot Password</a>
                </div>
                <div class="col m6 s6">
                    <a href="<?php echo e(route('register')); ?>" class="grey-text">Sign Up</a>
                </div>
            </div>

           </div>
       </div>
    </div>

</div>
<?php /**PATH C:\Users\user\Desktop\Leonard\Development\PHP\Laravel\NewProjects\BTCInvestor\resources\views/components/login-form.blade.php ENDPATH**/ ?>