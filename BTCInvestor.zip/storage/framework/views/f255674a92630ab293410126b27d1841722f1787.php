<div>

    <section style="background: <?php echo e(env('APP_GREY_HEADER_COLOR')); ?> !important;" class="py-2 mb-5">
        <div class="container">
            <h2 class="py-2" style="color: <?php echo e(env('APP_TEAL_COLOR')); ?> !important;"><?php echo $__env->yieldContent('page-name'); ?></h2>
            
        </div>
    </section>

</div>
<?php /**PATH C:\Users\user\Desktop\Leonard\Development\PHP\Laravel\NewProjects\BTCInvestor\resources\views/components/page-header.blade.php ENDPATH**/ ?>