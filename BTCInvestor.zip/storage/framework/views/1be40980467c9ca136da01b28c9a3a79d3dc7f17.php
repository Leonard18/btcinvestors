<?php $__env->startSection('headerContent'); ?>
    <meta name="description" content="<?php echo e(config('app.name')); ?> User Dashboard">
    <title><?php echo e(config('app.name')); ?> - Dashboard</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-name'); ?>
    Dashboard
    <?php $__env->startSection('small-page-name', 'home'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginale1e8d5675b2a7852d6e3603878bf3c460df21033 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UserDetails::class, []); ?>
<?php $component->withName('user-details'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginale1e8d5675b2a7852d6e3603878bf3c460df21033)): ?>
<?php $component = $__componentOriginale1e8d5675b2a7852d6e3603878bf3c460df21033; ?>
<?php unset($__componentOriginale1e8d5675b2a7852d6e3603878bf3c460df21033); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    
     <div class="my-5">

    <div class="container-fluid p-5 rounded" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important;">
        <div class="section-header">
            <h3 class="pb-4 underline" style="color: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">Account Section</h3>
        </div>
       <div class="row">
            <!-- Investment -->
        <div class="col-md-3 col-sm-6 col-lg-3">
            <div class="card  blue darken-2 white-text py-3">
            <h1 class="center"><span style="text-shadow: 2px 2px 1px darkgray">&#x20A6;</span> <br> <?php echo e($deposit); ?></h1>
            <h4 class="center">Deposits</h4>
            </div>
          </div>

          <!-- Earned -->
          <div class="col-md-3 col-sm-6 col-lg-3">
            <div class="card  purple darken-2 white-text py-3">
            <h1 class="center"><span style="text-shadow: 2px 2px 1px darkgray">&#x20A6;</span> <br>  <?php echo e($investment); ?></h1>
            <h4 class="center">Invested</h4>
            </div>
          </div>

          <!-- Commisions -->
          <div class="col-md-3 col-sm-6 col-lg-3">
            <div class="card gold darken-2 white-text py-3">
            <h1 class="center"><span style="text-shadow: 2px 2px 1px darkgray">&#x20A6;</span> <br>  <?php echo e($earning); ?></h1>
            <h4 class="center">Earnings</h4>
            </div>
          </div>

          <!-- Withdrawn -->
          <div class="col-md-3 col-sm-6 col-lg-3">
            <div class="card green darken-2 white-text py-3">
            <h1 class="center"><span style="text-shadow: 2px 2px 1px darkgray">&#x20A6;</span> <br>  <?php echo e($withdrawable); ?></h1>
            <h4 class="center">Withdrawable</h4>
            </div>
          </div>
       </div>
    </div>

</div>
    


	
	
	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
		<div class="my-5">

        <div class="container-fluid p-5 rounded" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important;">
            <h3 class="pb-4 underline" style="color: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">Active Investments</h3>

           <table class="table responsive-table table-striped table-hover">
               <thead class="green lighten-1 white-text">
                   <tr>
                       <th data-field="id">#</th>
                       <th data-field="name">Plan</th>
                       <th data-field="price">Comm. rate</th>
                       <th data-field="price">Expiring date</th>
                       <th data-field="price">Activation Date</th>
                       <th data-field="price">Invested amount</th>
                       <th data-field="price">Return amount</th>
                   </tr>
               </thead>
               <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $activeInvestments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($investment->id); ?></td>
                        <td><?php echo e($investment->plan_name); ?></td>
                        <td><?php echo e($investment->plan_percent); ?></td>
                        <td><?php echo e($investment->plan_duration); ?></td>
                        <td><?php echo e($investment->updated_at->diffForHumans()); ?></td>
                        <td><?php echo e($investment->investment_amount); ?></td>
                        <td><?php echo e($investment->expected_amount); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <tr>
                          <td colspan="7">There are no active investments.</td>
                      </tr>
                  <?php endif; ?>
               </tbody>
           </table>

          </div>

    </div>

	<?php endif; ?>
    


    
    <div class="my-5">

    <div class="container-fluid p-5 rounded" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important;">
        <h3 class="pb-4 underline" style="color: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">Your Deposits History</h3>

       <table class="table responsive-table table-striped table-hover">
           <thead class="blue darken-4 white-text">
               <tr>
                   <th data-field="id">#</th>
                   <th data-field="name">Plan name</th>
                   <th data-field="price">Investment amount</th>
                   <th data-field="price">Return interval</th>
                   <th data-field="price">Plan Percentage (%)</th>
                   <th data-field="price">Status</th>
                   <th data-field="price">Date</th>
               </tr>
           </thead>
           <tbody>
               <?php $__empty_1 = true; $__currentLoopData = $userDeposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                   <td><?php echo e($deposit->id); ?></td>
                   <td><?php echo e($deposit->plan_name); ?></td>
                   <td><?php echo e($deposit->investment_amount); ?></td>
                   <td><?php echo e($deposit->plan_interval); ?></td>
                   <td><?php echo e($deposit->plan_percent); ?></td>
                   <td><?php echo e($deposit->status ? 'Active' : 'Not Active'); ?></td>
                   <td><?php echo e($deposit->created_at->diffForHumans()); ?></td>
                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                   <tr>
                      <td colspan="7">You don't have any deposits.</td>
                   </tr>
               <?php endif; ?>
           </tbody>
       </table>

      </div>

</div>

    



    
	
	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
		<div class="my-5">

        <div class="container-fluid p-5 rounded" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important;">
            <h3 class="pb-4 underline" style="color: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">Withdrawal Requests</h3>

           <table class="table responsive-table table-striped table-hover">
               <thead class="gold darken-4 white-text">
                   <tr>
                       <th data-field="id">#</th>
                       <th data-field="amnount">Amount</th>
                       <th data-field="user">User</th>
                       <th data-field="status">Status</th>
                       <th data-field="approved">Approved</th>
                       <th data-field="date">Date</th>
                       <th data-field="action">Action</th>
                   </tr>
               </thead>
               <tbody>
                   <?php $__empty_1 = true; $__currentLoopData = $withdrawalRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdrawalRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                       <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($withdrawalRequest->amount); ?></td>
                          <td><?php echo e($withdrawalRequest->user->username); ?></td>
                          <td><?php echo e($withdrawalRequest->status); ?></td>
                          <td class="font-bold <?php echo e($withdrawalRequest->approved ? 'green-text' : 'red-text'); ?>"><?php echo e($withdrawalRequest->approved ? "PAID" : "UNPAID"); ?></td>
                          <td><?php echo e($withdrawalRequest->created_at->diffForHumans()); ?></td>
                          <td>
                              <a onclick="event.preventDefault(); if(confirm('Are you sure?')) { document.getElementById('approve-<?php echo e($withdrawalRequest->id); ?>-<?php echo e($withdrawalRequest->id); ?>').submit() }" class="btn btn-small green darken-2 white-text <?php echo e($withdrawalRequest->approved ? 'disabled' : ''); ?> ">Approve</a>

                              <form id="approve-<?php echo e($withdrawalRequest->id); ?>-<?php echo e($withdrawalRequest->id); ?>" action="<?php echo e(route('approve', $withdrawalRequest->id)); ?>" method="post">
                                  <?php echo csrf_field(); ?>

                              </form>

                          </td>
                       </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                       <tr>
                           <td colspan="6">There are no withdrawal requests yet.</td>
                       </tr>
                   <?php endif; ?>
               </tbody>
           </table>

          </div>

    </div>
	<?php endif; ?>
    
    



    
    <div class="my-5">

        <div class="container-fluid p-5 rounded" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important;">
            <h3 class="pb-4 underline" style="color: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">Your Withdrawal Requests</h3>

           <table class="table responsive-table table-striped table-hover">
               <thead class="teal darken-2 white-text">
                   <tr>
                       <th data-field="id">#</th>
                       <th data-field="amnount">Amount</th>
                       <th data-field="status">Status</th>
                       <th data-field="approved">Approved</th>
                       <th data-field="date">Date</th>
                   </tr>
               </thead>
               <tbody>
                   <?php $__empty_1 = true; $__currentLoopData = auth()->user()->withdrawalrequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userwithdrawalRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                       <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($userwithdrawalRequest->amount); ?></td>
                          <td><?php echo e($userwithdrawalRequest->status); ?></td>
                          <td class="font-bold <?php echo e($userwithdrawalRequest->approved ? 'green-text' : 'red-text'); ?>"><?php echo e($userwithdrawalRequest->approved ? 'PAID' : 'UNPAID'); ?></td>
                          <td><?php echo e($userwithdrawalRequest->created_at->diffForHumans()); ?></td>
                       </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                       <tr>
                           <td colspan="6">You don't have any withdrawal requests yet.</td>
                       </tr>
                   <?php endif; ?>
               </tbody>
           </table>

          </div>

    </div>
    


    
    <div class="my-5">

        <div class="container-fluid p-5 rounded" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important;">
            <h3 class="pb-4 underline" style="color: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">Your Transaction History</h3>

           <table class="table responsive-table table-striped table-hover">
               <thead class="orange darken-2 white-text">
                   <tr>
                       <th data-field="id">#</th>
                       <th data-field="name">Type</th>
                       <th data-field="price">Description</th>
                       <th data-field="price">Date</th>
                       <th data-field="price">Status</th>
                   </tr>
               </thead>
               <tbody>
                   <?php $__empty_1 = true; $__currentLoopData = $userTrans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userTran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                       <tr>
                          <td><?php echo e($userTran->id); ?></td>
                          <td><?php echo e($userTran->type); ?></td>
                          <td><?php echo e($userTran->description); ?></td>
                          <td><?php echo e($userTran->created_at); ?></td>
                          <td><?php echo e($userTran->status); ?></td>
                       </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                       <tr>
                           <td colspan="6">There are no transactions yet. Create one.</td>
                       </tr>
                   <?php endif; ?>
               </tbody>
           </table>

          </div>

    </div>
    



    
	
	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
		<div class="my-5">

    <div class="container-fluid p-5 rounded" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important;">

        <div class="row">
            <div class="col s6 l6">
                <h3 class="pb-4 underline" style="color: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">All Transaction History</h3>
            </div>
            <div class="col s2 l2 offset-s4 offset-l4">
               <!-- Modal Trigger -->
               <a class="waves-effect waves-light btn modal-trigger blue darken-4 white-text" href="#modal-transaction">Add Transaction</a>

               <!-- Modal Structure -->
               <div id="modal-transaction" class="modal modal-fixed-footer py-3">
                 <div class="modal-content">
                   <h4>Add New Transaction for a User</h4>
                   <p>Create a new transaction and assign it to a user.</p>
                   <hr>
                   <div class="row">
                       <div class="col s12 l12">
                           <form action="<?php echo e(route('transaction.store')); ?>" method="POST">
                               <?php echo csrf_field(); ?>
                               <div class="input-field col s12 l4">
                                <select name="user" id="user">
                                    <option selected disabled>Select user</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->username); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option disabled>No user</option>
                                    <?php endif; ?>
                                </select>
                                <label for="duration" data-error="wrong" data-success="right">Select user<span class="red-text"> *</span></label>
                            </div>
                            <div class="input-field col s12 l4">
                                <select name="type" id="type">
                                    <option selected disabled>Transaction type</option>
                                    <option value="debit">Debit</option>
                                    <option value="deposit">Deposit</option>
                                    <option value="credit">Credit</option>
                                    <option value="reversal">Reversal</option>
                                    <option value="withdrawal">Withdrawal</option>
                                    <option value="earning">Earning</option>
                                </select>
                                <label for="duration" data-error="wrong" data-success="right">Transaction type<span class="red-text"> *</span></label>
                            </div>
                            <div class="input-field col s12 l4">
                                <select name="status" id="status">
                                    <option selected disabled>Select status</option>
                                    <option value="success">Success</option>
                                    <option value="declined">Declined</option>
                                    <option value="reversed">Reversed</option>
                                    <option value="pending">Pending</option>
                                    <option value="held">Held</option>
                                    <option value="approved">Approved</option>
                                    <option value="awaiting approval">Awaiting Approval</option>
                                </select>
                                <label for="duration" data-error="wrong" data-success="right">Transaction status<span class="red-text"> *</span></label>
                            </div>
                            <div class="input-field col s12 l12">
                                <textarea id="description" name="description" class="materialize-textarea"  cols="30" rows="10"></textarea>
                                <label for="description" data-error="wrong" data-success="right">Transaction description<span class="red-text"> *</span></label>
                            </div>
                       </div>
                   </div>
                 </div>
                 <div class="modal-footer">
                    <button type="submit" class="btn btn-large blue darken-4 white-text">Add Transaction</button>
                   <a href="#!" class=" modal-action modal-close waves-effect waves-green btn-flat">Close</a>
                 </div>
               </form>
               </div>
            </div>
        </div>

       <table class="table responsive-table table-striped table-hover">
           <thead class="blue darken-4 white-text">
               <tr>
                   <th data-field="id">#</th>
                   <th data-field="type">Type</th>
                   <th data-field="description">Description</th>
                   <th data-field="username">Username</th>
                   <th data-field="date">Date</th>
                   <th data-field="status">Status</th>
                   <th>Actions</th>
               </tr>
           </thead>
           <tbody>
               <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                   <tr>
                      <td><?php echo e($transaction->id); ?></td>
                      <td><?php echo e($transaction->type); ?></td>
                      <td><?php echo e($transaction->description); ?></td>
                      <td><?php echo e($transaction->username); ?></td>
                      <td><?php echo e($transaction->created_at); ?></td>
                      <td><?php echo e($transaction->status); ?></td>
                      <td>

                        


                            <form action="<?php echo e(route('transaction.destroy', $transaction->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn red darken-1 white-text">DELETE</button>
                            </form>
                      </td>
                   </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                   <tr>
                       <td colspan="7">There are no transactions yet. Create one.</td>
                   </tr>
               <?php endif; ?>
           </tbody>
       </table>

      </div>

</div>
	<?php endif; ?>
    




    <div class="my-5">

        <div class="container-fluid p-5 rounded" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important;">
           <div class="row justify-content-between">
               <div class="col-md-10">
                 <h3 class="pb-4 underline" style="color: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">Investment Plans</h3>
               </div>
               <div class="col-md-2 pt-3">

                    <!-- Modal Trigger -->
			
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
				<a class="waves-effect waves-light btn modal-trigger purple darken-2 white-text" href="#modal-plan">Add Plan</a>
			<?php endif; ?>
                    

                    <!-- Modal Structure -->
                    <div id="modal-plan" class="modal modal-fixed-footer py-3">
                      <div class="modal-content">
                        <h4>Add New Investment Plan</h4>
                        <p>Add an investment plan to allow users a new investment opportunity.</p>
                        <hr>
                        <div class="row">
                            <div class="col s12 l12">
                                <form action="<?php echo e(route('plan.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="input-field col s12 l4">
                                        <input type="text" name="name" id="name" class="validate" placeholder="Name of investment plan">
                                        <label for="name" data-error="wrong" data-success="right">Plan Name<span class="red-text"> *</span></label>
                                    </div>

                                    <div class="input-field col s12 l4">
                                        <input type="number" name="percentage" id="percentage" class="validate" placeholder="Percentage of plan">
                                        <label for="percentage" data-error="wrong" data-success="right">Plan Percentage<span class="red-text"> *</span></label>
                                    </div>

                                    <div class="input-field col s12 l4">
                                        <select name="interval" id="interval">
                                            <option selected disabled>Select plan in</option>
                                            <option value="1">Weekly</option>
                                            <option value="2">Bi-Weekly</option>
                                            <option value="3">Monthly </option>
                                            <option value="4">Two Months</option>
                                            <option value="5">Three Months</option>
                                            <option value="6">Six Months</option>
                                            <option value="7">Ten Months</option>
					    <option value="8">Twelve Months</option>
                                        </select>
                                        <label for="interval" data-error="wrong" data-success="right">Plan Interval<span class="red-text"> *</span></label>
                                    </div>

                                     <div class="input-field col s12 l4">
                                        <select name="duration" id="duration">
                                            <option value="" selected disabled>Select plan duration</option>
                                            <option value="Weekly">Weekly</option>
                                            <option value="Bi-Weekly">Bi-Weekly</option>
                                            <option value="Monthly">Monthly</option>
                                            <option value="Two Months">Two Months</option>
                                            <option value="Three Months">Three Months</option>
                                            <option value="Six Months">Six Months</option>
                                            <option value="Ten Months">Ten Months</option>
                                            <option value="Twelve Months">Twelve Months</option>
                                            <option value="Twelve Months">Fifteen Months</option>
                                            <option value="Twelve Months">Eighteen Months</option>
                                            <option value="Twelve Months">Twenty-four Months</option>
                                            <option value="Twelve Months">Thirty-six Months</option>
                                        </select>
                                        <label for="duration" data-error="wrong" data-success="right">Plan Duration<span class="red-text"> *</span></label>
                                    </div>

                                     <div class="input-field col s12 l4">
                                        <input type="color" name="background_color" id="background_color" class="validate p-1" style="width: 100% !important; border: 2px solid black !important;">
                                        <label for="background_color" data-error="wrong" data-success="right">Plan Background Color<span class="red-text"> *</span></label>
                                    </div>

                                    <div class="input-field col s12 l4">
                                        <input type="color" name="text_color" id="text_color" class="validate p-1" style="width: 100% !important; border: 2px solid black !important;">
                                        <label for="text_color" data-error="wrong" data-success="right">Plan Text Color<span class="red-text"> *</span></label>
                                    </div>

                                    <div class="input-field col s12 l12">
                                        <textarea id="description" name="description" class="materialize-textarea" placeholder="Describe plan" cols="30" rows="10"></textarea>
                                        <label for="description" data-error="wrong" data-success="right">Plan Description<span class="red-text"> *</span></label>
                                    </div>
                            </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                         <button type="submit" class="btn btn-large purple darken-2 white-text">Add New Plan</button>
                        <a href="#!" class=" modal-action modal-close waves-effect waves-green btn-flat">Close</a>
                      </div>
                    </form>
                    </div>

               </div>

            </div>

           <table class="table responsive-table table-striped table-hover">
               <thead class="purple darken-2 white-text">
                   <tr>
                       <th data-field="id">#</th>
                       <th data-field="name">Name</th>
                       <th data-field="price">Commission rate</th>
                       <th data-field="price">Payment interval</th>
                       <th data-field="price">Plan Duration</th>
                       <th data-field="price">Description</th>
                       <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?> <th>Actions</th> <?php endif; ?>
                   </tr>
               </thead>
               <tbody>
                   <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($plan->name); ?></td>
                        <td><?php echo e($plan->percentage); ?>%</td>
                        <td>paid once every <strong><?php echo e($plan->interval_name); ?></strong></td>
                        <td><?php echo e($plan->duration); ?></td>
                        <td><?php echo e($plan->description); ?></td>
                        
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
					<td>


                        <!-- Modal Trigger -->
                    <a class="waves-effect waves-light modal-trigger green-text darken-2 font-bold" href="#modal-<?php echo e($plan->name); ?>-edit-<?php echo e($plan->id); ?>">UPDATE</a>

                    <!-- Modal Structure -->
                    <div id="modal-<?php echo e($plan->name); ?>-edit-<?php echo e($plan->id); ?>" class="modal modal-fixed-footer py-3">
                      <div class="modal-content">
                        <h4>Update <strong> <?php echo e($plan->name); ?> </strong> Investment Plan</h4>
                        <p>Update plan to something more refined and increase your ROI.</p>
                        <hr>
                        <div class="row">
                            <div class="col s12 l12">
                                <form action="<?php echo e(route('plan.update', $plan->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="input-field col s12 l4">
                                        <input type="text" name="name" id="name" class="validate" value="<?php echo e($plan->name); ?>">
                                        <label for="name" data-error="wrong" data-success="right">Plan Name<span class="red-text"> *</span></label>
                                    </div>

                                    <div class="input-field col s12 l4">
                                        <input type="number" name="percentage" id="percentage" class="validate" value="<?php echo e($plan->percentage); ?>">
                                        <label for="percentage" data-error="wrong" data-success="right">Plan Percentage<span class="red-text"> *</span></label>
                                    </div>

                                    <div class="input-field col s12 l4">
                                        <select name="interval" id="interval">
                                            <option value="<?php echo e($plan->interval); ?>" selected><?php echo e($plan->interval_name); ?></option>
                                            <option value="1">Weekly</option>
                                            <option value="2">Bi-Weekly</option>
                                            <option value="3">Monthly</option>
                                            <option value="4">Two Monthly</option>
                                            <option value="5">Three Months</option>
                                            <option value="6">Six Months</option>
                                            <option value="7">Ten Months</option>
                                            <option value="8">Twelve Months</option>
                                        </select>
                                        <label for="interval" data-error="wrong" data-success="right">Plan Interval<span class="red-text"> *</span></label>
                                    </div>

                                     <div class="input-field col s12 l4">
                                        <select name="duration" id="duration">
                                            <option value="<?php echo e($plan->duration); ?>" selected><?php echo e($plan->duration); ?></option>
                                            <option value="Weekly">Weekly</option>
                                            <option value="Bi-Weekly">Bi-Weekly</option>
                                            <option value="Monthly">Monthly</option>
                                            <option value="Two Months">Two Monthly</option>
                                            <option value="Three Months">Three Months</option>
                                            <option value="Six Months">Six Months</option>
                                            <option value="Ten Months">Ten Months</option>
                                            <option value="Twelve Months">Twelve Months</option>
                                        </select>
                                        <label for="duration" data-error="wrong" data-success="right">Plan Duration<span class="red-text"> *</span></label>
                                    </div>

                                     <div class="input-field col s12 l4">
                                        <input type="color" name="background_color" id="background_color" class="validate p-1" style="width: 100% !important; border: 2px solid black !important;" value="<?php echo e($plan->background_color); ?>">
                                        <label for="background_color" data-error="wrong" data-success="right">Plan Background Color<span class="red-text"> *</span></label>
                                    </div>

                                    <div class="input-field col s12 l4">
                                        <input type="color" name="text_color" id="text_color" class="validate p-1" style="width: 100% !important; border: 2px solid black !important;" value="<?php echo e($plan->text_color); ?>">
                                        <label for="text_color" data-error="wrong" data-success="right">Plan Text Color<span class="red-text"> *</span></label>
                                    </div>

                                    <div class="input-field col s12 l12">
                                        <textarea id="description" name="description" class="materialize-textarea cols="30" rows="10"><?php echo e($plan->description); ?></textarea>
                                        <label for="description" data-error="wrong" data-success="right">Plan Description<span class="red-text"> *</span></label>
                                    </div>
                            </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                         <button type="submit" class="btn btn-large green darken-2 white-text">Add New Plan</button>
                        <a href="#!" class=" modal-action modal-close waves-effect waves-green btn-flat">Close</a>
                      </div>
                    </form>
                    </div>
                            <a href="" class="red-text text-darken-2 font-bold ml-1" onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($plan->id); ?>-<?php echo e($plan->id); ?>').submit();">DELETE</a>

                            <form id="delete-form-<?php echo e($plan->id); ?>-<?php echo e($plan->id); ?>" action="<?php echo e(route('plan.destroy', $plan->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>

                        </td>
			<?php endif; ?>
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7">There are no plans. Create new one.</td>
                    </tr>
                   <?php endif; ?>
               </tbody>
           </table>

          </div>

    </div>


    
	
	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
			<div class="my-5">

    <div class="container-fluid p-5 rounded" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important;">
        <h3 class="pb-4 underline" style="color: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">All Deposit History</h3>

       <table class="table responsive-table table-striped table-hover">
           <thead class="blue darken-2 white-text">
               <tr>
                   <th data-field="id">#</th>
                   <th data-field="name">Plan name</th>
                   <th data-field="price">Amount</th>
                   <th data-field="price">Interval</th>
                   <th data-field="price">Username</th>
                   <th data-field="price">Percentage (%)</th>
                   <th data-field="price">Status</th>
                   <th data-field="price">Date</th>
                   <th data-field="price"></th>
               </tr>
           </thead>
           <tbody>
               <?php $__empty_1 = true; $__currentLoopData = $allDeposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alldeposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                   <td><?php echo e($alldeposit->id); ?></td>
                   <td><?php echo e($alldeposit->plan_name); ?></td>
                   <td><?php echo e($alldeposit->investment_amount); ?></td>
                   <td><?php echo e($alldeposit->plan_interval); ?></td>
                   <td><?php echo e($alldeposit->username); ?></td>
                   <td><?php echo e($alldeposit->plan_percent); ?></td>
                   <td><?php echo e($alldeposit->status ? 'Active' : 'Not Active'); ?></td>
                   <td><?php echo e($alldeposit->created_at->diffForHumans()); ?></td>
                   <td>
                        <form action="<?php echo e(route('deposit-update', $alldeposit->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn <?php echo e($alldeposit->status ? 'red' : 'green'); ?> white-text"><?php echo e($alldeposit->status ? 'DEACTIVATE' : 'ACTIVATE'); ?></button>
                        </form>
                    </td>



                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                   <tr>
                      <td colspan="9">There are no deposits.</td>
                   </tr>
               <?php endif; ?>
           </tbody>
       </table>

      </div>

</div>

	<?php endif; ?>
    



    <?php if (isset($component)) { $__componentOriginal12325e736ca4281b39394176e2872d8c205dfb67 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CalenderCalculator::class, []); ?>
<?php $component->withName('calender-calculator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal12325e736ca4281b39394176e2872d8c205dfb67)): ?>
<?php $component = $__componentOriginal12325e736ca4281b39394176e2872d8c205dfb67; ?>
<?php unset($__componentOriginal12325e736ca4281b39394176e2872d8c205dfb67); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

     
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerContent'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Leonard\Development\PHP\Laravel\NewProjects\BTCInvestor\resources\views/user/dashboard.blade.php ENDPATH**/ ?>