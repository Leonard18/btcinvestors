<div>

    <nav style="background: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">
      <div class="nav-wrapper">
        <div class="container">
          <a href="#" class="brand-logo">BTCInvestor</a>
          <a href="#" data-target="mobile-menu" class="sidenav-trigger hide-on-med-and-up"><i class="fa fa-bars fa-2x" aria-hidden="true"></i></a>
          <ul class="right hide-on-med-and-down">
            <li class="<?php echo e(Route::is('home') ? 'active' : ''); ?>"><a href="<?php echo e(route('home')); ?>" class="<?php echo e(Route::is('/') ? 'teal-text' : 'white-text'); ?>">HOME</a></li>
            <li class="<?php echo e(Route::is('about') ? 'active' : ''); ?>"><a href="<?php echo e(route('about')); ?>">ABOUT US</a></li>
            <li class="<?php echo e(Route::is('plans') ? 'active' : ''); ?>"><a href="<?php echo e(route('plans')); ?>">PLANS</a></li>
            <?php if(auth()->guard()->guest()): ?>
                <li><a href="<?php echo e(route('login')); ?>">LOG IN</a></li>
                <li><a href="<?php echo e(route('register')); ?>">SIGN UP</a></li>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <li class="<?php echo e(Route::is('dashboard') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard')); ?>">DASHBOARD</a></li>
                <li class="<?php echo e(Route::is('settings') ? 'active' : ''); ?>"><a href="<?php echo e(route('settings')); ?>">SETTINGS</a></li>
            <?php endif; ?>
            <li class="<?php echo e(Route::is('blog.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('blog.index')); ?>">BLOG</a></li>

            <li class="<?php echo e(Route::is('contact') ? 'active' : ''); ?>"><a href="<?php echo e(route('contact')); ?>">CONTACT US</a></li>
          </ul>

          
          <ul class="sidenav blue darken-3" id="mobile-menu">
              <h2 class="center my-5 font-bold"><?php echo e(config('app.name')); ?></h2>

            <li class="<?php echo e(Route::is('home') ? 'active' : ''); ?>">
               <a href="<?php echo e(route('home')); ?>" class="<?php echo e(Route::is('home') ? 'white-text' : 'grey-text'); ?>"><?php echo e(__('Home')); ?></a>
            </li>

            <li class="<?php echo e(Route::is('about') ? 'active' : ''); ?>">
              <a href="<?php echo e(route('about')); ?>" class="<?php echo e(Route::is('about') ? 'white-text' : 'grey-text text-lighten-2'); ?>"><?php echo e(__('About Us')); ?></a>
            </li>

            <li class="<?php echo e(Route::is('plans') ? 'active' : ''); ?>"><a href="<?php echo e(route('plans')); ?>" class="<?php echo e(Route::is('plans') ? 'white-text' : 'grey-text text-lighten-2'); ?>">Investment Plans</a></li>
            <?php if(auth()->guard()->guest()): ?>
                <li><a href="<?php echo e(route('login')); ?>" class="<?php echo e(Route::is('login') ? 'white-text' : 'grey-text text-lighten-2'); ?>">Log In</a></li>
                <li><a href="<?php echo e(route('register')); ?>" class="<?php echo e(Route::is('register') ? 'white-text' : 'grey-text text-lighten-2'); ?>">Sign Up</a></li>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <li><a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(Route::is('dashboard') ? 'white-text' : 'grey-text text-lighten-2'); ?>">Dashboard</a></li>

                <li><a href="<?php echo e(route('profile')); ?>" class="<?php echo e(Route::is('profile') ? 'white-text' : 'grey-text text-lighten-2'); ?>">Profile</a></li>

                <li><a href="<?php echo e(route('settings')); ?>" class="<?php echo e(Route::is('settings') ? 'white-text' : 'grey-text text-lighten-2'); ?>">Settings</a></li>
            <?php endif; ?>
            <li class="<?php echo e(Route::is('blog.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('blog.index')); ?>" class="<?php echo e(Route::is('blog.index') ? 'white-text' : 'grey-text text-lighten-2'); ?>">Blog</a></li>

            <li class="<?php echo e(Route::is('contact') ? 'active' : ''); ?>" class="<?php echo e(Route::is('contact') ? 'white-text' : 'grey-text'); ?>"><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>

            <li class="<?php echo e(Route::is('terms') ? 'active' : ''); ?>"><a href="<?php echo e(route('terms')); ?>" class="<?php echo e(Route::is('terms') ? 'white-text' : 'grey-text text-lighten-2'); ?>">Terms of Service</a></li>

            <li class="<?php echo e(Route::is('policy') ? 'active' : ''); ?>"><a href="<?php echo e(route('policy')); ?>" class="<?php echo e(Route::is('policy') ? 'white-text' : 'grey-text text-lighten-2'); ?>">Privacy Policy</a></li>
          </ul>
        </div>
      </div>
    </nav>

</div>
<?php /**PATH C:\Users\user\Desktop\Leonard\Development\PHP\Laravel\NewProjects\BTCInvestor\resources\views/components/navigation.blade.php ENDPATH**/ ?>