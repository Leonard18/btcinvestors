<?php $__env->startSection('headerContent'); ?>
   <meta name="description" content="Login - <?php echo e(config('app.name')); ?>">
   <title><?php echo e(config('app.name')); ?> - Login</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-name'); ?>
    Login
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <section style="background: <?php echo e(env('APP_WHITE_COLOR')); ?>" class="p-5 container">
       <div class="row">
           <div class="col-md-5 my-3 p-5">
               <h3 class="pb-2">Access Your Account</h3>
               <p>Login to access your account profile.</p>
               <p>Make sure you're on the right URL <button class="btn rounded" disabled><strong class="black-text"><?php echo e(route('login')); ?> </strong></button> before entering your login details.</p>
           </div>
           <div class="col-md-6 offset-md-1">
               <?php if (isset($component)) { $__componentOriginal9cdd66cb0f1750fccbf716dbfefdd56b448bf904 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\LoginForm::class, []); ?>
<?php $component->withName('login-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal9cdd66cb0f1750fccbf716dbfefdd56b448bf904)): ?>
<?php $component = $__componentOriginal9cdd66cb0f1750fccbf716dbfefdd56b448bf904; ?>
<?php unset($__componentOriginal9cdd66cb0f1750fccbf716dbfefdd56b448bf904); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
           </div>
       </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerContent'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Leonard\Development\PHP\Laravel\NewProjects\BTCInvestor\resources\views/auth/login.blade.php ENDPATH**/ ?>