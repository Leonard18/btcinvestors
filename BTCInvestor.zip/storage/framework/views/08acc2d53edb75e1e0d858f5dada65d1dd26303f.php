<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/materialize.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <title><?php echo e(config('app.name')); ?> - Home</title>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->yieldContent('headerContent'); ?>
</head>
<body style="background: <?php echo e(env('APP_BODY_COLOR')); ?> !important;">

    <?php if (isset($component)) { $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navigation::class, []); ?>
<?php $component->withName('navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e)): ?>
<?php $component = $__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e; ?>
<?php unset($__componentOriginale50e17b184145c8d671bd4a72ac0d887f47f1a0e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal600a327acf366e6f7b3d45dd618d786767653501 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slideshow::class, []); ?>
<?php $component->withName('slideshow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal600a327acf366e6f7b3d45dd618d786767653501)): ?>
<?php $component = $__componentOriginal600a327acf366e6f7b3d45dd618d786767653501; ?>
<?php unset($__componentOriginal600a327acf366e6f7b3d45dd618d786767653501); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginald95a73917d90b480296c7c28291e7adc0e09b6fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WelcomeSection::class, []); ?>
<?php $component->withName('welcome-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald95a73917d90b480296c7c28291e7adc0e09b6fb)): ?>
<?php $component = $__componentOriginald95a73917d90b480296c7c28291e7adc0e09b6fb; ?>
<?php unset($__componentOriginald95a73917d90b480296c7c28291e7adc0e09b6fb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <div class="my-5">

        <div class="container-fluid p-5" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important;">
            <h2 class="pb-4 underline" style="color: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">Investment Plans           </h2>
            <div class="row">

                <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 col-lg-6">
                    <div class="card" style="background: <?php echo e($plan->background_color); ?>">
                        <div class="card-header center" style="width: 100% !important;">
                            <h1 class="card-title font-weight-bold" style="color: <?php echo e($plan->text_color); ?> !important;"><?php echo e($plan->name); ?></h1>
                        </div>
                        <div class="card-content center" style="color: <?php echo e($plan->text_color); ?>">
                            <h1 class="price-header"><?php echo e($plan->percentage); ?>%</h1>
                            <p>paid once every <?php echo e($plan->interval_name); ?></p>
                        </div>
                        <div class="card-action center">
                            <!-- Button trigger modal -->
                            <a class="btn-link" data-toggle="modal" data-target="#modelId-<?php echo e($plan->id); ?>" style="cursor: pointer !important; color: <?php echo e($plan->text_color); ?>;">
                              View details
                            </a>

                            <button class="btn btn-large my-3 btn-block font-weight-bolder" style="background: <?php echo e($plan->text_color); ?>;"><a href="<?php echo e(route('make-deposit')); ?>" style="color: <?php echo e($plan->background_color); ?>">INVEST NOW</a></button>

                            <!-- Modal -->
                            <div class="modal fade" id="modelId-<?php echo e($plan->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                            <div class="modal-header">
                                                    <h5 class="modal-title"><?php echo e($plan->name); ?></h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                </div>
                                        <div class="modal-body">
                                            <div class="container-fluid">
                                                Add rows here
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            <button type="button" class="btn btn-primary">Save</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <script>
                                $('#exampleModal').on('show.bs.modal', event => {
                                    var button = $(event.relatedTarget);
                                    var modal = $(this);
                                    // Use above variables to manipulate the DOM

                                });
                            </script>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>There are no plans on the platform. Create one</p>
                <?php endif; ?>


                </div>
            </div>
        </div>


    


    

    <div class="my-5">

        <section class="container p-5" style="background: <?php echo e(env('APP_WHITE_COLOR')); ?> !important;">
            <div class="row">
               <div class="col-md-6">
                   <h1 class="pb-2" style="color: <?php echo e(env('APP_PRIMARY_COLOR')); ?>">Calculate Your Investment.</h1>
                    <p>Know how much you will earn on any amount you invest.</p>
                    <p>We are always here to clerify any doubts and to answer any questions that you may have.</p>
               </div>
               <div class="col-md-5 offset-md-1 center">
                    <div class="row">
                        <div class="col-md-12 m-2">
                            <div class="form-group">
                                <label for=""></label>
                                <input type="text" class="form-control rounded" name="" id="" placeholder="Enter amount" style="border: 2px solid <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important; height: 40px !important;">
                                
                            </div>
                        </div>
                        <div class="col-md-12 m-2">
                            <div class="form-group">
                                <select class="form-control rounded p-1" name="" id="" style="border: 2px solid <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important; height: 40px !important;">
                                  <option selected disabled>Select investment plan</option>
                                  <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($plan->id); ?>"><?php echo e($plan->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                  <?php endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <button class="btn btn-block btn-large white-text font-weight-bold" style="background: <?php echo e(env('APP_PRIMARY_COLOR')); ?> !important;">CALCULATE</button>
                    </div>
               </div>
            </div>
        </section>

    </div>



    <?php if (isset($component)) { $__componentOriginalfd0d1533e2cdbc19b9f3d326feae54053933890b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CredibilitySection::class, []); ?>
<?php $component->withName('credibility-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfd0d1533e2cdbc19b9f3d326feae54053933890b)): ?>
<?php $component = $__componentOriginalfd0d1533e2cdbc19b9f3d326feae54053933890b; ?>
<?php unset($__componentOriginalfd0d1533e2cdbc19b9f3d326feae54053933890b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal0046fcbc67ec534af27676224ce878a6886c6405 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ChooseUs::class, []); ?>
<?php $component->withName('choose-us'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0046fcbc67ec534af27676224ce878a6886c6405)): ?>
<?php $component = $__componentOriginal0046fcbc67ec534af27676224ce878a6886c6405; ?>
<?php unset($__componentOriginal0046fcbc67ec534af27676224ce878a6886c6405); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal99843580f067249f9ed6ac259729d2bf4b8605e4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Testimonials::class, []); ?>
<?php $component->withName('testimonials'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal99843580f067249f9ed6ac259729d2bf4b8605e4)): ?>
<?php $component = $__componentOriginal99843580f067249f9ed6ac259729d2bf4b8605e4; ?>
<?php unset($__componentOriginal99843580f067249f9ed6ac259729d2bf4b8605e4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal13610164919dfea9b04570f55a5cc0e524186229 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BadgesSection::class, []); ?>
<?php $component->withName('badges-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal13610164919dfea9b04570f55a5cc0e524186229)): ?>
<?php $component = $__componentOriginal13610164919dfea9b04570f55a5cc0e524186229; ?>
<?php unset($__componentOriginal13610164919dfea9b04570f55a5cc0e524186229); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


    <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/materialize.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('footerContent'); ?>
</body>
</html>
<?php /**PATH C:\Users\user\Desktop\Leonard\Development\PHP\Laravel\NewProjects\BTCInvestor\resources\views/pages/home.blade.php ENDPATH**/ ?>