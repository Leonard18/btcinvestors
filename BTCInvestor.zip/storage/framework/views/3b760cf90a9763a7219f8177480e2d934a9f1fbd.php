<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/materialize.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->yieldContent('headerContent'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body style="background: <?php echo e(env('APP_BODY_COLOR')); ?> !important;">

    <?php if (isset($component)) { $__componentOriginalb054d3531141f5fec2542cfcde6f886a0b66c3be = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UserNavigation::class, []); ?>
<?php $component->withName('user-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb054d3531141f5fec2542cfcde6f886a0b66c3be)): ?>
<?php $component = $__componentOriginalb054d3531141f5fec2542cfcde6f886a0b66c3be; ?>
<?php unset($__componentOriginalb054d3531141f5fec2542cfcde6f886a0b66c3be); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginaleb1e1f9ad28bfc6e782ae3fd5d7fa1ba0ef19ee0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UserPageHeader::class, []); ?>
<?php $component->withName('user-page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginaleb1e1f9ad28bfc6e782ae3fd5d7fa1ba0ef19ee0)): ?>
<?php $component = $__componentOriginaleb1e1f9ad28bfc6e782ae3fd5d7fa1ba0ef19ee0; ?>
<?php unset($__componentOriginaleb1e1f9ad28bfc6e782ae3fd5d7fa1ba0ef19ee0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <main>

        <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                <span class="sr-only">Close</span>
            </button>
            <strong>Success!  </strong> <?php echo e(Session::get('success')); ?>

        </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Close</span>
                </button>
                <strong>Error!  </strong> <?php echo e(Session::get('error')); ?>

            </div>
        <?php endif; ?>
        
        <?php echo $__env->yieldContent('content'); ?>


        
        
        
        <?php if (isset($component)) { $__componentOriginala951cf6278013cff435157919677a3c926f1ae80 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UserFooter::class, []); ?>
<?php $component->withName('user-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginala951cf6278013cff435157919677a3c926f1ae80)): ?>
<?php $component = $__componentOriginala951cf6278013cff435157919677a3c926f1ae80; ?>
<?php unset($__componentOriginala951cf6278013cff435157919677a3c926f1ae80); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </main>

    

    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/materialize.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/user.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('footerContent'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>


     
     <script>
        $(document).ready(function(){
            $('#userDrop').click(function() {
                $('#userContent').toggleClass('show');
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\Users\user\Desktop\Leonard\Development\PHP\Laravel\NewProjects\BTCInvestor\resources\views/layouts/app.blade.php ENDPATH**/ ?>