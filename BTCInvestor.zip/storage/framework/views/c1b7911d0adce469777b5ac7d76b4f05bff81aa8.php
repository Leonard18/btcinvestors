<div class="mt-7 mb-1">
   
    <div class="container-fluid py-2" style="background: <?php echo e(env('APP_PRIMARY_COLOR')); ?>">
       <div class="container">
           <div class="row">

               
               <div class="col-md-6">
                  <p>
                      <a href="<?php echo e(route('policy')); ?>" class="white-text">Privacy Policy</a>
                      <a href="<?php echo e(route('terms')); ?>" class="white-text ml-2">Terms of Service</a>
                  </p> 
               </div>
               
               
               <div class="col-md-6">
                <p class="white-text">&copy; <span class="ml-2 mr-2"><?php echo e(Carbon::now()->year); ?></span> <a href="<?php echo e(route('home')); ?>" class="white-text mr-2"><?php echo e(config('app.name')); ?>.</a> <span>All rights reserved.</span></p>
               </div>
           </div>
       </div>
    </div>

</div><?php /**PATH C:\Users\user\Desktop\Leonard\Development\PHP\Laravel\NewProjects\BTCInvestor\resources\views/components/user-footer.blade.php ENDPATH**/ ?>